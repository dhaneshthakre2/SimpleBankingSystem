package demo.SimpleBankingSystem;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();

        bank.addCustomer(1, "Dhanesh Thakre", "dhanesh@example.com");
        bank.addCustomer(2, "Dhiraj Thakre", "dhiraj@example.com");

        bank.createAccount(101, 1);
        bank.createAccount(102, 2);

        bank.performTransaction(101, 1000, true);
        bank.performTransaction(102, 500, true);
        bank.performTransaction(101, 200, false);

        bank.displayAccountDetails(101);
        bank.displayAccountDetails(102);
        bank.displayAccountDetails(103);  // Non-existent account
    }
}
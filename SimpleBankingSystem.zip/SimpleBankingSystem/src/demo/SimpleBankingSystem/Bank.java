package demo.SimpleBankingSystem;
import java.util.ArrayList;
import java.util.List;

public class Bank {
	private List<Customer> customers;
    private List<Account> accounts;

    public Bank() {
        customers = new ArrayList<>();
        accounts = new ArrayList<>();
    }

    public void addCustomer(int customerId, String name, String contactInfo) {
        Customer customer = new Customer(customerId, name, contactInfo);
        customers.add(customer);
        System.out.println("Customer added: " + customer.getName());
    }

    public void createAccount(int accountNumber, int customerId) {
        Customer customer = findCustomer(customerId);
        if (customer != null) {
            Account account = new Account(accountNumber, customer);
            accounts.add(account);
            System.out.println("Account created for Customer: " + customer.getName() + ", Account #: " + account.getAccountNumber());
        } else {
            System.out.println("Customer not found with ID: " + customerId);
        }
    }

    public void performTransaction(int accountNumber, double amount, boolean isDeposit) {
        Account account = findAccount(accountNumber);
        if (account != null) {
            if (isDeposit) {
                account.deposit(amount);
            } else {
                account.withdraw(amount);
            }
        } else {
            System.out.println("Account not found with Account #: " + accountNumber);
        }
    }

    public void displayAccountDetails(int accountNumber) {
        Account account = findAccount(accountNumber);
        if (account != null) {
            Customer customer = account.getAccountHolder();
            System.out.println("Account Details:");
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Account Holder: " + customer.getName());
            System.out.println("Contact Info: " + customer.getContactInfo());
            System.out.println("Balance: " + account.getBalance());
        } else {
            System.out.println("Account not found with Account #: " + accountNumber);
        }
    }

    private Customer findCustomer(int customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId) {
                return customer;
            }
        }
        return null;
    }

    private Account findAccount(int accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }
}



